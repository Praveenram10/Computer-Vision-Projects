README
Object Detection with YOLOv8
OVERVIEW
This project uses YOLOv8 for object detection in images.
It detects objects, draws bounding boxes, and displays class names and confidence scores.

FEATURES
Detects objects in images.
Draws bounding boxes around detected objects.
Displays class names and confidence scores.
Saves the output image.

PERSONAL ISSUE I FACED
 Having stable version of python is not enough we need to have something greater than 3.9 and lesser than 3.11 , I personally chose 3.10.9 (for stability and bug fixes)

LIBRARIES
OpenCV: For image processing.
Ultralytics: For YOLOv8 model and object detection.

INSTALLATION
Install required libraries: pip install opencv-python ultralytics

USAGE
Download YOLOv8 Model
Run Script On Terminal
python detect_objects.py --model_path "x" --input_path "x" --output_path "x" (script for Image(jpg) , script for video(mp4))

MODEL PATH: Location to the YOLOv8 model file (ex: yolov8n.pt)
INPUT PATH: Path to your video file (ex: input_video.mp4)
OUTPUT PATH: Path to save the output video with the detected objects (ex: output_video.mp4)


Made by Praveen Ram


